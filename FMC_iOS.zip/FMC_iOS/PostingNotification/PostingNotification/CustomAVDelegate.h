//
//  CustomAVDelegate.h
//  PostingNotification
//
//  Created by FMCAdmin on 3/5/14.
//  Copyright (c) 2014 FMCAdmin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CustomAVDelegate : NSObject <UIAlertViewDelegate>

@end
