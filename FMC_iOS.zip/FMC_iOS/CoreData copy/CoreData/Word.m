//
//  Word.m
//  CoreData
//
//  Created by FMCAdmin on 3/7/14.
//  Copyright (c) 2014 FMCAdmin. All rights reserved.
//

#import "Word.h"


@implementation Word

@dynamic translation;
@dynamic word;
@dynamic vocabulary;

@end
