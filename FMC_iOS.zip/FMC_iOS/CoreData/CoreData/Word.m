//
//  Word.m
//  CoreData
//
//  Created by FMCAdmin on 3/7/14.
//  Copyright (c) 2014 FMCAdmin. All rights reserved.
//

#import "Word.h"
#import "Vocabulary.h"


@implementation Word

@dynamic word;
@dynamic translation;
@dynamic vocabulary;

@end
