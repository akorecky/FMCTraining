//
//  Vocabulary.m
//  CoreData
//
//  Created by FMCAdmin on 3/7/14.
//  Copyright (c) 2014 FMCAdmin. All rights reserved.
//

#import "Vocabulary.h"
#import "Word.h"


@implementation Vocabulary

@dynamic name;
@dynamic words;

@end
