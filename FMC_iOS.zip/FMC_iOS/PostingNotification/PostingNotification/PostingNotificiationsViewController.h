//
//  PostingNotificiationsViewController.h
//  PostingNotification
//
//  Created by FMCAdmin on 3/5/14.
//  Copyright (c) 2014 FMCAdmin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomAVDelegate.h"

@interface PostingNotificiationsViewController : UIViewController {
    CustomAVDelegate *customDelegate;
    
    
}

@end
